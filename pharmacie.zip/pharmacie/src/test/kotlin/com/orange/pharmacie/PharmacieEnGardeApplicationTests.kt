package com.orange.pharmacie

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class PharmacieEnGardeApplicationTests {

	@Test
	fun contextLoads() {
	}

}
