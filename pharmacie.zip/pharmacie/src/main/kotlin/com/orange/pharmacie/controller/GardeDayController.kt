package com.orange.pharmacie.controller

import com.orange.pharmacie.dto.GardeDayDto
import com.orange.pharmacie.dto.GardeDayDtoPharmacie
import com.orange.pharmacie.dto.mapper.GardeDayMapper.toDto
import com.orange.pharmacie.dto.mapper.GardeDayMapper.toGardeDayDto
import com.orange.pharmacie.service.GardeDayService
import jakarta.validation.Valid
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/garde")
class GardeDayController(val gardeDayService: GardeDayService) {


    @PostMapping("/ajouter")
    fun createGarde(@RequestBody @Valid gardeDayDtoPharmacie: GardeDayDtoPharmacie): ResponseEntity<GardeDayDto> {
        val gardeDay = gardeDayService.createGardeDayWithPharmacies(
            gardeDayDtoPharmacie.toGardeDayDto(),
            gardeDayDtoPharmacie.pharmacieIds
        )
        return ResponseEntity.ok(gardeDay.toDto())
    }


}