package com.orange.pharmacie.service

import com.orange.pharmacie.dto.GetPharmacieDto
import com.orange.pharmacie.dto.PharmacieDto
import com.orange.pharmacie.dto.PharmacieGardeSummaryDto
import com.orange.pharmacie.model.Pharmacie
import com.orange.pharmacie.repository.PharmacieRepository
import org.springframework.stereotype.Service

import org.slf4j.Logger
import org.slf4j.LoggerFactory


import com.orange.pharmacie.dto.mapper.PharmacieMapping.toEntity
import com.orange.pharmacie.repository.AssignmentPharmacieGardeRepository
import java.time.LocalDate


@Service
class PharmacieServiceImplementation ( val pharmacieRepository: PharmacieRepository,val assignmentRepository:AssignmentPharmacieGardeRepository) : PharmacieService{
    override fun create(pharmacieDto: PharmacieDto): Pharmacie {
       this.pharmacieRepository.save(pharmacieDto.toEntity())
        return pharmacieDto.toEntity()
    }

    override fun readAll(): MutableList<GetPharmacieDto> {
     return  this.pharmacieRepository.findAll().map { pharmacie ->
            GetPharmacieDto(
                id = pharmacie.id,
                code = pharmacie.code,
                name = pharmacie.name,
                isEnable = pharmacie.isEnabled
            )
        }.toMutableList()
    }

    override fun update(id: Long, updatedPharmacie: PharmacieDto): Pharmacie {
        val pharmacie = pharmacieRepository.findById(id).orElseThrow { Exception("Pharmacie not found") }
        pharmacie.name = updatedPharmacie.name
        pharmacie.isEnabled = pharmacie.isEnabled
        return pharmacieRepository.save(pharmacie)
    }

    override fun deleteByCode(code : String): Boolean {
         val logger: Logger = LoggerFactory.getLogger(PharmacieServiceImplementation::class.java)
        val pharmacie = pharmacieRepository.findPharmacieByCode(code)
        logger.warn("pharmacie : $pharmacie")
        return if (pharmacie != null) {
            pharmacieRepository.delete(pharmacie)
            true
        } else {
            false
        }
    }



   override fun getPharmaciesWithGardesBetween(startDate: LocalDate, endDate: LocalDate): List<PharmacieGardeSummaryDto> {
        val assignments = assignmentRepository.findByGardeDayDayOfGardeBetween(startDate, endDate)

        val grouped = assignments.groupBy { it.pharmacie }

        return grouped.map { (pharmacie, assList) ->
            PharmacieGardeSummaryDto(
                id = pharmacie.id,
                name = pharmacie.name,
                code = pharmacie.code,
                isEnabled = pharmacie.isEnabled,
                joursDeGarde = assList.map { it.gardeDay.dayOfGarde }
            )
        }
    }


}


