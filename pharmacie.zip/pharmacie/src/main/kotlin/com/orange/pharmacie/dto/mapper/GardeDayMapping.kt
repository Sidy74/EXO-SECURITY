package com.orange.pharmacie.dto.mapper

import com.orange.pharmacie.dto.GardeDayDto
import com.orange.pharmacie.dto.GardeDayDtoPharmacie
import com.orange.pharmacie.model.GardeDay


object GardeDayMapper {

    fun GardeDayDto.toEntity(): GardeDay {
        return GardeDay(
            dayOfGarde = this.dayOfGarde
        )
    }

    fun GardeDay.toDto(): GardeDayDto {
        return GardeDayDto(
            dayOfGarde = this.dayOfGarde
        )
    }

    fun GardeDayDtoPharmacie.toEntity(): GardeDay {
        return GardeDay(
            dayOfGarde = this.dayOfGarde
        )
    }


    fun GardeDayDtoPharmacie.toGardeDayDto(): GardeDayDto {
        return GardeDayDto(
            dayOfGarde = this.dayOfGarde
        )
    }


}