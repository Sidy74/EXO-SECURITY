package com.orange.pharmacie.controller

import com.orange.pharmacie.dto.GetPharmacieDto
import com.orange.pharmacie.dto.PharmacieDto
import com.orange.pharmacie.dto.PharmacieGardeSummaryDto
import com.orange.pharmacie.model.Pharmacie
import com.orange.pharmacie.service.PharmacieService
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import java.time.LocalDate


@RestController
@RequestMapping("/pharmacies")
class PharmacieController(
   private val  pharmacieService:PharmacieService){


   @PostMapping("/ajouter")
   fun ajouter(@RequestBody pharmacieDto: PharmacieDto): Pharmacie {
      return   pharmacieService.create(pharmacieDto)
   }

  @GetMapping
   fun recupererTout(): List<GetPharmacieDto> {
      return pharmacieService.readAll()
   }


    @DeleteMapping("/supprimer/{code}")
    fun supprimer(@PathVariable code: String): Boolean {
        return pharmacieService.deleteByCode(code)
    }


    @GetMapping("/garde")
    fun getPharmaciesByGardePeriod(
        @RequestParam start: LocalDate,
        @RequestParam end: LocalDate
    ): ResponseEntity<List<PharmacieGardeSummaryDto>> {
        val result = pharmacieService.getPharmaciesWithGardesBetween(start, end)
        return ResponseEntity.ok(result)
    }
}

