package com.orange.pharmacie.model

import jakarta.persistence.*
import java.time.LocalDate

@Entity
@Table(name = "garde")
data class GardeDay (@Id @GeneratedValue(strategy = GenerationType.IDENTITY) val id: Long = 0,
                var dayOfGarde: LocalDate = LocalDate.now(),
                @OneToMany(mappedBy = "gardeDay", cascade = [CascadeType.ALL], orphanRemoval = true)
                var assignmentPharmacieGardes: MutableList<AssignmentPharmacieGarde> = mutableListOf()){
}