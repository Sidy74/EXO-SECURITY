package com.orange.pharmacie.service

import com.orange.pharmacie.dto.GetPharmacieDto
import com.orange.pharmacie.dto.PharmacieDto
import com.orange.pharmacie.dto.PharmacieGardeSummaryDto
import com.orange.pharmacie.model.Pharmacie
import java.time.LocalDate


interface PharmacieService {

    fun create(pharmacieDto: PharmacieDto): Pharmacie

    fun readAll(): MutableList<GetPharmacieDto> ;

//    fun readById(id: Long): Pharmacie?;
//
    fun update(id: Long, updatedPharmacie: PharmacieDto): Pharmacie;
//
//    fun disablePharmacie(id: Long);
//
    fun deleteByCode(code : String):Boolean;

    fun getPharmaciesWithGardesBetween(startDate: LocalDate, endDate: LocalDate): List<PharmacieGardeSummaryDto>

}