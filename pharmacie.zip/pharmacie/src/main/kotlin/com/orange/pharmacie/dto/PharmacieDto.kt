package com.orange.pharmacie.dto

data class PharmacieDto(
    var name: String,
) {
}

data class GetPharmacieDto(
    var id: Long,
    var code : String,
    var name: String,
    var isEnable: Boolean = true
) {
}


data class PharmacieDtoDelete(
    var code: String,
    var name: String,
) {
}