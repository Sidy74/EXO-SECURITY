package com.orange.pharmacie.repository

import com.orange.pharmacie.model.Pharmacie
import org.aspectj.apache.bcel.classfile.Code
import org.springframework.data.jpa.repository.JpaRepository


interface PharmacieRepository : JpaRepository<Pharmacie, Long> {
    fun findPharmacieByCode(code: String): Pharmacie?
    fun deletePharmacieByName(name: String): Pharmacie?
}
