

package com.orange.pharmacie.model

import jakarta.persistence.CascadeType
import jakarta.persistence.Entity
import jakarta.persistence.EntityListeners

import jakarta.persistence.GeneratedValue
import jakarta.persistence.GenerationType
import jakarta.persistence.Id
import jakarta.persistence.OneToMany
import jakarta.persistence.Table
import java.time.LocalTime

@Entity
@Table
@EntityListeners(PharmacieListener::class)
data class Pharmacie (
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    var id: Long = 0,

    var code: String = "",

    var name: String = "",

//    var adresse: String = "",

//    var ouverture: LocalTime? = null,
//
//    var fermeture: LocalTime? = null,

//    var longitude: Double = 0.0,

//    var latitude :Double =0.0,
//
//    var phone: String = "",

    var isEnabled: Boolean = true,


    @OneToMany(mappedBy = "pharmacie", cascade = [CascadeType.ALL], orphanRemoval = true)
    var assignmentPharmacieGardes: MutableList<AssignmentPharmacieGarde> = mutableListOf()

){

}