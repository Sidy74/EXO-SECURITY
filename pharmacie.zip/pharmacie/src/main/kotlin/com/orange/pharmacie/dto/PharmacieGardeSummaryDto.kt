package com.orange.pharmacie.dto

import java.time.LocalDate

data class PharmacieGardeSummaryDto(
        val id: Long,
        val name: String,
        val code: String,
        val isEnabled: Boolean,
        val joursDeGarde: List<LocalDate>
    )

