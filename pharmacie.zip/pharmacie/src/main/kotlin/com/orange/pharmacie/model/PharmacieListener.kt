package com.orange.pharmacie.model

import jakarta.persistence.PrePersist
import java.util.UUID

class PharmacieListener {
    @PrePersist
    fun prePersist(pharmacie: Pharmacie) {
        if (pharmacie.code.isBlank()) {
            pharmacie.code = "PHARM-${UUID.randomUUID().toString().substring(0, 8).uppercase()}"
        }
    }
}