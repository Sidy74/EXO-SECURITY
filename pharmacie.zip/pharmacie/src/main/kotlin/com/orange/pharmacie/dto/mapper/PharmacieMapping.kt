package com.orange.pharmacie.dto.mapper

import com.orange.pharmacie.dto.GetPharmacieDto
import com.orange.pharmacie.dto.PharmacieDto
import com.orange.pharmacie.dto.PharmacieDtoDelete
import com.orange.pharmacie.model.Pharmacie

object PharmacieMapping {

    // Extension pour l'entité vers DTO
    fun Pharmacie.toDto() = PharmacieDto(
        name = this.name,
    )

    fun Pharmacie.toDtoGet() = GetPharmacieDto(
        id = this.id,
        code = this.code,
        name = this.name,
        isEnable = this.isEnabled,
    )


    // Extension pour DTO vers entité
    fun PharmacieDto.toEntity() = Pharmacie(
        name =this.name,
    )

    fun PharmacieDtoDelete.toEntity() = Pharmacie(
        code = this.code,
        name = this.name,
    )

}