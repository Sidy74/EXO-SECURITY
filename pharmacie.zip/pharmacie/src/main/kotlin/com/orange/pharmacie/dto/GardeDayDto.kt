package com.orange.pharmacie.dto

import jakarta.validation.constraints.NotEmpty
import java.time.LocalDate

data class GardeDayDto (
                         val dayOfGarde: LocalDate) {
}

data class GardeDayDtoPharmacie ( @field:NotEmpty(message = "Il faut au moins une pharmacie")
                                  val dayOfGarde: LocalDate,
                                  val pharmacieIds: List<Long>

) {
}