package com.orange.pharmacie.repository

import com.orange.pharmacie.model.GardeDay
import org.springframework.data.jpa.repository.JpaRepository

interface GardeDayRepository : JpaRepository<GardeDay, Long> {
 }