package com.orange.pharmacie

import lombok.EqualsAndHashCode.Exclude
import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication


@SpringBootApplication
class PharmacieEnGardeApplication()

fun main(args: Array<String>) {
	runApplication<PharmacieEnGardeApplication>(*args)
}
