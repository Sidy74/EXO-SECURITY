package com.orange.pharmacie.repository

import com.orange.pharmacie.model.AssignmentPharmacieGarde
import org.springframework.data.jpa.repository.JpaRepository
import java.time.LocalDate

interface AssignmentPharmacieGardeRepository :JpaRepository<AssignmentPharmacieGarde, Long> {
    fun findByGardeDayDayOfGardeBetween(start: LocalDate, end: LocalDate): List<AssignmentPharmacieGarde>

}