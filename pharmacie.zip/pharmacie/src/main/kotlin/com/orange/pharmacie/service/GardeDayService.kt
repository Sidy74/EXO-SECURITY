package com.orange.pharmacie.service

import com.orange.pharmacie.dto.GardeDayDto
import com.orange.pharmacie.model.GardeDay
import com.orange.pharmacie.model.Pharmacie

interface GardeDayService {
    fun createGardeDayWithPharmacies(
        gardeDayDto: GardeDayDto,
        pharmacieIds:List<Long>
    ): GardeDay
}