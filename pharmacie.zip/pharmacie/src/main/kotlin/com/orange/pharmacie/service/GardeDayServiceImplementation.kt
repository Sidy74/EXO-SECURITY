package com.orange.pharmacie.service

import com.orange.pharmacie.dto.GardeDayDto
import com.orange.pharmacie.dto.mapper.GardeDayMapper.toEntity
import com.orange.pharmacie.model.AssignmentPharmacieGarde
import com.orange.pharmacie.model.GardeDay
import com.orange.pharmacie.model.Pharmacie
import com.orange.pharmacie.repository.GardeDayRepository
import com.orange.pharmacie.repository.PharmacieRepository
import org.springframework.stereotype.Service

@Service
class GardeDayServiceImplementation(val pharmacieRepository:PharmacieRepository,val gardeDayRepository:GardeDayRepository) : GardeDayService {

    override fun createGardeDayWithPharmacies(
        gardeDayDto: GardeDayDto,
        pharmacieIds: List<Long>
    ): GardeDay {
        if (pharmacieIds.isEmpty()) {
            throw IllegalArgumentException("Une garde doit être associée à au moins une pharmacie.")
        }

        // 1. Convertir le DTO en entité
        val gardeDay = gardeDayDto.toEntity()

        // 2. Récupérer les pharmacies en BDD
        val pharmacies = pharmacieRepository.findAllById(pharmacieIds)

        if (pharmacies.size != pharmacieIds.size) {
            throw IllegalArgumentException("Une ou plusieurs pharmacies sont introuvables.")
        }

        // 3. Créer et associer les assignments
        val assignments = pharmacies.map { pharmacie ->
            AssignmentPharmacieGarde(pharmacie = pharmacie, gardeDay = gardeDay).also {
                pharmacie.assignmentPharmacieGardes.add(it)
            }
        }

        gardeDay.assignmentPharmacieGardes.addAll(assignments)

        // 4. Sauvegarder
        return gardeDayRepository.save(gardeDay)
    }
}