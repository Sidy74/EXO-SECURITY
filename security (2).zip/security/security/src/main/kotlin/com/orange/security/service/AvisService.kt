package com.orange.security.service

import com.orange.security.Repository.AvisRepository
import com.orange.security.dto.AvisDto
import com.orange.security.dto.Mapper.AvisMapping.toDto
import com.orange.security.dto.Mapper.AvisMapping.toEntity
import org.springframework.stereotype.Service

@Service
class AvisService (val avisRepository: AvisRepository) {

     fun  creeAvis(avisDto:AvisDto) :AvisDto{
        val avis = this.avisRepository.save(avisDto.toEntity())
         return avis.toDto();
     }

}