package com.orange.security.dto

import com.orange.security.model.Avis

class AvisDto ( val message:String,val status :String) {

}