package com.orange.security.controller

import com.orange.security.dto.AvisDto
import com.orange.security.service.AvisService
import org.springframework.http.HttpStatus
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.ResponseStatus
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/avis")
class AvisController(val avisService: AvisService) {

   @ResponseStatus(HttpStatus.CREATED)
    @PostMapping
    fun creer(avisDto: AvisDto):AvisDto{
      return  this.avisService.creeAvis(avisDto)
    }
}