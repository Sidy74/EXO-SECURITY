package com.orange.security.model

import jakarta.persistence.*

@Entity
@Table(name = "avis")
data class Avis (@Id @GeneratedValue(strategy = GenerationType.IDENTITY) val id:Long =0, val message:String,val status :String) {

}