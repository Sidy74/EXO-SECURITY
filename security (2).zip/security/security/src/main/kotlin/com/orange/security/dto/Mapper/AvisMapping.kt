package com.orange.security.dto.Mapper

import com.orange.security.dto.AvisDto
import com.orange.security.model.Avis

object AvisMapping {

    fun AvisDto.toEntity(): Avis {
        return Avis(
            message = this.message,
            status = this.status
        )
    }
    fun Avis.toDto(): AvisDto {
        return AvisDto(
            message = this.message,
            status = this.status
        )
    }
}