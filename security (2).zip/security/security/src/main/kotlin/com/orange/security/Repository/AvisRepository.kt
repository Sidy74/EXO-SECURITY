package com.orange.security.Repository

import com.orange.security.model.Avis
import org.springframework.data.jpa.repository.JpaRepository

interface AvisRepository :JpaRepository<Avis,Long> {
}